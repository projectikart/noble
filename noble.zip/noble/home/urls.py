from django.conf.urls import url
from . import views

urlpatterns =[
url(r'mgretailer',views.mgretailer,name='mgretailer'),
url(r'index',views.home,name='home'),
url(r'addlimit',views.addlimit,name='addlimit')
]
