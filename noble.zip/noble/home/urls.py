from django.conf.urls import url
from . import views

urlpatterns =[
url(r'mgretailer',views.mgretailer,name='mgretailer'),
url(r'index',views.home,name='home'),
url(r'addlimit',views.addlimit,name='addlimit'),
url(r'deleteretailer',views.deleteretailer,name='deleteretailer'),
url(r'updateretailer',views.updateretailer,name='updateretailer'),
url(r'depositor',views.depositor,name='depositor'),
url(r'transactions',views.ttransactions,name='transactions'),
url(r'newtransaction',views.newtransaction,name='newtransaction'),
]
