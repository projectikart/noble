from django.http import *
from decimal import *
from django.template import loader
from .models import *
from datetime import datetime, timedelta, date
from django.db.models import Sum

def home(request):
    r=retailer.objects.all()
    template=loader.get_template('home/home.html')



    try :
        bookeep=bookkeep.objects.get(date=date.today())
    except :
        bookeep=bookkeep.objects.get(date=date.today()- timedelta(days=1))
        bookkeep1=bookkeep(cbal=bookeep.cbal,obal=bookeep.cbal,profit=0,date=date.today())
        bookkeep1.save()
        bookeep=bookkeep.objects.get(date=date.today())

    #totallend and totaldebt
    totallend=retailer.objects.aggregate(Sum('mtr'))
    totallend=totallend.get('mtr__sum')
    if totallend < 0:
        totaldebt=abs(totallend)
        context ={'r':r,'totallend':0,'totaldebt':totaldebt,'bookeep':bookeep}
    else:
        context ={'r':r,'totallend':totallend,'totaldebt':0.00,'bookeep':bookeep}

    return HttpResponse(template.render(context,request))

def addlimit(request):
    template=loader.get_template('home/addlimit.html')
    print(request.GET.get("amount", ""))
    print(request.GET.get("id", ""))

    return HttpResponse(template.render())

def mgretailer(request):
    template=loader.get_template('home/mgretailer.html')
    r=retailer.objects.all().filter().order_by('name')
    print(r)
    context ={
    'r':r,
    }
    return HttpResponse(template.render(context,request))
# Create your views here.

#delete Retailers
def deleteretailer(request):
    iden=request.GET.get("id", "")
    retailer.objects.filter(id=iden).delete()

    return HttpResponseRedirect('home/mgretailer.html')

def updateretailer(request):
    template=loader.get_template('home/updateretailer.html')
    iden=request.GET.get("id", "")
    r=retailer.objects.all().filter(id=iden)
    context ={
    'r':r,
    }
    return HttpResponse(template.render(context,request))

def depositor(request):
    template=loader.get_template('home/depositor.html')
    return HttpResponse(template.render())

def ttransactions(request):

    

    template=loader.get_template('home/transactions.html')
    return HttpResponse(template.render())

def newtransaction(request):
    amtdbt=request.GET.get("requestlimit", 0)
    amtrcv=request.GET.get("amountreceived", 0)

    rname=request.GET.get("retailername", 0)
    n=rname.split(" - ")
    rn=str(n[0])
    ra=str(n[1])
    r=retailer.objects.all().filter(addr=ra,name=rn)

#start to refer to doc 101
    flag1=True
    flag2=True
    if Decimal(amtdbt) < 0 :
        flag1=False
        for re in r:
            debt=Decimal(amtdbt)-Decimal(amtrcv)
            re.rqtlmt=re.rqtlmt+Decimal(amtdbt)
            re.save()

    if Decimal(amtrcv) < 0 :
        flag2=False
        for re in r:
            debt=Decimal(amtdbt)-Decimal(amtrcv)
            re.mtr=re.mtr-abs(debt)
            re.save()
# end to refer to doc 101


    if request.GET.get("check", "off")=="off":#some or no amount is received ie requestlimit !=amountreceived

        for re in r:
            print(re.id)
            t=transactions(rid=re.id,datetime=datetime.now(),amtcdr=amtrcv,amtdbt=amtdbt)
            t.save()
            bookkeep1=bookkeep.objects.get(date=date.today())

            #update profit
            p=bookkeep1.profit + Decimal(amtdbt)*Decimal(0.002)
            bookkeep1.profit=Decimal(p)

            #current or closing balance
            c=bookkeep1.cbal-Decimal(amtdbt)+Decimal(amtdbt)*Decimal(0.0051)
            bookkeep1.cbal=Decimal(c)
            bookkeep1.save()

            #updating debt when amount recieved=0

            if Decimal(amtdbt) > Decimal(amtrcv) and flag2==True:
                debt=Decimal(amtdbt)-Decimal(amtrcv)
                re.rqtlmt=re.rqtlmt+Decimal(amtdbt)
                re.mtr=re.mtr+abs(debt)
                re.save()
            elif Decimal(amtdbt) < Decimal(amtrcv) and flag1==True:
                debt=Decimal(amtdbt)-Decimal(amtrcv)
                re.rqtlmt=re.rqtlmt+Decimal(amtdbt)
                re.mtr=re.mtr-abs(debt)
                re.save()
                break

    else:

        for re in r:
            print(re.id)
            t=transactions(rid=re.id,datetime=datetime.now(),amtcdr=amtrcv,amtdbt=amtdbt)
            t.save()
            bookkeep1=bookkeep.objects.get(date=date.today())

            #update profit
            p=bookkeep1.profit + Decimal(amtdbt)*Decimal(0.002)
            bookkeep1.profit=Decimal(p)

            #current or closing balance
            c=bookkeep1.cbal-Decimal(amtdbt)+Decimal(amtdbt)*Decimal(0.0051)
            bookkeep1.cbal=Decimal(c)
            bookkeep1.save()

            #retailer request limit update
            re.rqtlmt=re.rqtlmt+Decimal(amtdbt)
            re.save()
            break




    return HttpResponseRedirect('home/index.html')

'''
cbal=Decimal(amtrcv)*Decimal(0.0031)+bookkeep1.cbal+Decimal(cbal)-Decimal(amtdbt)*Decimal(0.0051)
bookkeep1.cbal=
bookkeep1.save()
'''
