from django.http import HttpResponse
from django.template import loader
from .models import *

def home(request):
    r=retailer.objects.all()
    template=loader.get_template('home/home.html')

    context ={
    'r':r,
    }
    return HttpResponse(template.render(context,request))

def addlimit(request):
    template=loader.get_template('home/addlimit.html')
    print(request.GET.get("amount", ""))
    print(request.GET.get("id", ""))

    return HttpResponse(template.render())

def mgretailer(request):
    template=loader.get_template('home/mgretailer.html')
    r=retailer.objects.all()
    context ={
    'r':r,
    }
    return HttpResponse(template.render(context,request))
# Create your views here.
