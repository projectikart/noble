from django.http import *
from django.template import loader
from .models import *
from datetime import datetime, timedelta, date

def home(request):
    r=retailer.objects.all()
    template=loader.get_template('home/home.html')

    context ={
    'r':r,
    }
    return HttpResponse(template.render(context,request))

def addlimit(request):
    template=loader.get_template('home/addlimit.html')
    print(request.GET.get("amount", ""))
    print(request.GET.get("id", ""))

    return HttpResponse(template.render())

def mgretailer(request):
    template=loader.get_template('home/mgretailer.html')
    r=retailer.objects.all().filter().order_by('name')
    print(r)
    context ={
    'r':r,
    }
    return HttpResponse(template.render(context,request))
# Create your views here.

#delete Retailers
def deleteretailer(request):
    iden=request.GET.get("id", "")
    retailer.objects.filter(id=iden).delete()

    return HttpResponseRedirect('home/mgretailer.html')

def updateretailer(request):
    template=loader.get_template('home/updateretailer.html')
    iden=request.GET.get("id", "")
    r=retailer.objects.all().filter(id=iden)
    context ={
    'r':r,
    }
    return HttpResponse(template.render(context,request))

def depositor(request):
    template=loader.get_template('home/depositor.html')
    return HttpResponse(template.render())

def ttransactions(request):
    template=loader.get_template('home/transactions.html')
    return HttpResponse(template.render())

def newtransaction(request):
    if request.GET.get("check", "off")=="off":
        rname=request.GET.get("retailername", 0)
        n=rname.split(" - ")
        rn=str(n[0])
        ra=str(n[1])
        r=retailer.objects.all().filter(addr=ra,name=rn)
        for re in r:
            print(re.id)
            t=transactions(rid=re.id,datetime=datetime.now(),amtcdr=0,amtdbt=request.GET.get("requestlimit", 0))
            t.save()
            
            break



    else:
        #request.GET.get("amountreceived", 0)
        pass;
    return HttpResponseRedirect('home/index.html')
