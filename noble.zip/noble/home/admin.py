from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(retailer)
admin.site.register(bookkeep)
admin.site.register(depositor)
admin.site.register(rate)
admin.site.register(transactions)
