from django.db import models

# Create your models here.
class retailer(models.Model):
    #name,mobile no , address,balance, money to receive
    id=models.PositiveIntegerField(primary_key=True)
    name = models.CharField(max_length=250)
    #credit = models.DecimalField(max_digits=10, decimal_places=2)
    mob=models.BigIntegerField()
    addr=models.CharField(max_length=1000)
    mtr=models.BigIntegerField(default=0)
    gstin=models.CharField(max_length=15,default="None")

class bookkeep(models.Model):
    #closing balance , opening balance, profit, date
    cbal=models.PositiveIntegerField()
    obal=models.PositiveIntegerField()
    profit=models.PositiveIntegerField()
    datetime = models.DateTimeField(default='timezone.now')

class depositor(models.Model):
    name = models.CharField(max_length=250)
    amtcdr=models.BigIntegerField()
    amtdbt=models.BigIntegerField()

class rate(models.Model):
    #retailer stock rate ,distributer rate,depositor rate
     id=models.PositiveIntegerField(primary_key=True)
     rstr= models.DecimalField(max_digits=6, default='0.00510', decimal_places=5)
     dbtr= models.DecimalField(max_digits=6, default='0.00200', decimal_places=5)
     dptr= models.DecimalField(max_digits=6, default='0.00310', decimal_places=5)

class transactions(models.Model):
    #retailer id, date,amount credit,amount debited
    id=models.PositiveIntegerField(primary_key=True)
    rid=models.PositiveIntegerField()
    datetime = models.DateTimeField(default='timezone.now')
    amtcdr=models.BigIntegerField()#amount which is paid for topup amount(request limit) or to remove credit charge
    amtdbt=models.BigIntegerField() #amt which is taken as lend



    """
class TestClass(models.Model):
            t = models.TimeField()
            d = models.DateField()
            dt = models.DateTimeField()

        x = TestClass()

        x.t = datetime.time(12, 12, 12)
        x.d = datetime.date(2008, 3, 12)
        x.dt = datetime.datetime(2008, 3, 12, 12, 12, 12)
        WHERE startTime = '2010-04-29'
        WHERE startTime = '2010-04-29 00:00:00'
        WHERE startTime BETWEEN '2010-04-29 00:00:00' AND '2010-04-29 23:59:59'
WHERE startTime >= '2010-04-29' AND startTime < ('2010-04-29' + INTERVAL 1 DAY)
    """
