
#installing package
"""
   -m pip install django
'''
