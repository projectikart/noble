#starting an app
''' python manage.py startapp <appname>'''
# running python server
"""python manage.py runserver"""

# after or when ever there is a change to model
'''
python manage.py makemigrations hinterface
python manage.py migrate
'''


# django api shell
'''python manage.py shell'''

# input values to database
'''>>> from hinterface.models import product
>>> product.objects.all()
<QuerySet []>

>>> index=product(pid='p1',name='fgggf',price='43245')
>>> from hinterface.models import product
>>> product.objects.all()
<QuerySet []>
>>> index.save()
>>> index.pid
'p1'
>>> index.price
'43245'
>>> index.id
1
'''

# for seeing data of datbase or retrieving it
"""
>>> from hinterface.models import product
>>> product.objects.all()
<QuerySet [<product: p1-fgggf43245>, <product: p2-fgggf43245>]>
>>> product.objects.filter(pid='p1')
<QuerySet [<product: p1-fgggf43245>]>

>>> product.objects.filter(pid='p1')
<QuerySet [<product: p1-fgggf43245>]>
>>> product.objects.filter(id__startswith='1')
<QuerySet [<product: p1-fgggf43245>]>
"""




"""sending data from server api to web server"""
""">>> r = requests.get('http://127.0.0.1:8000/hinterface/additem', params={'key1':'ikart_s101','key2':'ikart_s101','key3':'ikart_s101','key4':'ikart_s101'})"""
 # r = requests.get('http://127.0.0.1:8000/hinterface/additem', params={'key1':'ikart_s101','key1':'ikart_s101','key1':'ikart_s101','key1':'ikart_s101'})

"""r = requests.get('http://127.0.0.1:8000/hinterface/additem', params={'key1':'Britania','key2':'555','key3':'BIS_BRI100','key4':'ikart_s101'})"""




""" TO ALLOW OTHER COMPUTER TO INTERACT WITH WEBSERVER
http://0.0.0.0:1234/

got to settings insert the ip address of current system
"""



"""
if we w ant to add a table to admin page we have to regiter it with admin.py
"""
